import QuizApp from './QuizApp'
import './App.css'

function App() {
  return (
    <>
      <QuizApp/>
    </>
  );
}

export default App
