import { useState } from 'react'
import FormComponent from './form'
import './App.css'

function App() {

  return (
   <>
    <FormComponent/>
   </>
  )
}

export default App
